window.onload = function() {
    const heading = document.getElementById('animated-heading');
    heading.style.opacity = '0';
    heading.style.transform = 'translateY(50px)';
  
    setTimeout(function() {
      heading.style.transition = 'opacity 1s, transform 1s';
      heading.style.opacity = '1';
      heading.style.transform = 'translateY(0)';
    }, 500);
  };

  const cartToggle = document.querySelector('.profile');
  const shoppingCart = document.getElementById('shopping-cart');
  
  cartToggle.addEventListener('click', () => {
    if (shoppingCart.style.display == 'none') {
      shoppingCart.style.display = 'block';
    } else {
      shoppingCart.style.display = 'none';
    }
  });
  
  const addToCartButtons = document.querySelectorAll('.food-items button');
  
  addToCartButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const foodItem = button.closest('.food-items');
      const name = foodItem.querySelector('.details h5').innerText;
      const price = parseFloat(foodItem.querySelector('.price').innerText.replace('Rs ', ''));
      addItemToCart(name, price);
    });
  });
  
  const cartItems = document.getElementById('cart-items');
  const cartTotal = document.querySelector('.cart-total-price');
  
  let cart = [];
  
  function addItemToCart(name, price) {
    const existingItem = cart.find((item) => item.name === name);
  
    if (existingItem) {
      existingItem.quantity++;
    } else {
      cart.push({ name, price, quantity: 1 });
    }
  
    updateCart();
  }
  
  function updateCart() {
      cartItems.innerHTML = '';
      let total = 0;
    
      cart.forEach((item) => {
        const cartRow = document.createElement('div');
        cartRow.classList.add('cart-row');
    
        const cartItem = document.createElement('span');
        cartItem.classList.add('cart-item', 'cart-column');
        cartItem.textContent = item.name;
        cartRow.appendChild(cartItem);
    
        const cartPrice = document.createElement('span');
        cartPrice.classList.add('cart-price', 'cart-column');
        cartPrice.textContent = `Rs ${item.price}`;
        cartRow.appendChild(cartPrice);
    
        const cartQuantity = document.createElement('span');
        cartQuantity.classList.add('cart-quantity', 'cart-column');
        cartQuantity.textContent = item.quantity;
        cartRow.appendChild(cartQuantity);
    
        cartItems.appendChild(cartRow);
    
        total += item.price * item.quantity;
      });
    
      const cartTotal = document.querySelector('.cart-total-price');
      cartTotal.textContent = `Rs ${total}`;
    }
    
    const total = items.reduce((acc, item) => acc + item.price * item.quantity, 0);
    cartTotal.textContent = `Rs ${total}`;
  
    const clickedButton= document.getElementsByClassName('addbtn');
  
    clickedButton.addEventListener('click',() =>{
      clickedButton.style.backgroundColor="red";
      clickedButton.style.transform=(translateY(1));
      clickedButton.style.transform=(translateX(1));
    });
  
  